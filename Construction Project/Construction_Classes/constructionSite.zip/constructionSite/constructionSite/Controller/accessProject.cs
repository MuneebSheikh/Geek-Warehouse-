﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace constructionSite.Controller
{
    class accessProject
    {
        public void AddNewProject(string date, string name, string contactNo, string plotNo, string status)
        {
            Project project = new Project();
            project.contactNo = contactNo;
            project.date = date;
            project.name = name;
            project.plotNo = plotNo;
            project.status = status;

            
            // insert to database;

        }
        public DataTable GetProjects()
        {
            //get from database
            DataTable dt = new DataTable();
            dt.Columns.Add("plotNo");
            dt.Columns.Add("clientName");
            dt.Columns.Add("status");

            DataRow r = dt.NewRow();
            r[0] = "574";
            r[1] = "uzair";
            r[2] = "complete";

            dt.Rows.Add(r);

            return dt;
        }
    }
}
