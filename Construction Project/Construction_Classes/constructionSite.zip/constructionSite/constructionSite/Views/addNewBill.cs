﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace constructionSite.Views
{
    public partial class addNewBill : Form
    {
        public addNewBill()
        {
            InitializeComponent();
        }
        

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            dashboard d = new dashboard();
            d.Show();
            this.Hide();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            addNewProject a = new addNewProject();
            a.Show();
            this.Hide();
        }

        private void txtBillNumber_OnValueChanged(object sender, EventArgs e)
        {
            txtBillNumber.Text = string.Concat(txtBillNumber.Text.Where(char.IsDigit));
        }

        private void addNewBill_Load(object sender, EventArgs e)
        {
            chkboxNaam.Checked = true;
            chkboxJama.Checked = false;
        }

        private void chkboxNaam_OnChange(object sender, EventArgs e)
        {
            if (chkboxJama.Checked == true)
             {
                chkboxJama.Checked = false;
             }
        }

        private void chkboxJama_OnChange(object sender, EventArgs e)
        {
            if (chkboxNaam.Checked == true)
            {
                chkboxNaam.Checked = false;
            }
        }

        private void txtAmount_OnValueChanged(object sender, EventArgs e)
        {
            txtAmount.Text = string.Concat(txtAmount.Text.Where(char.IsDigit));
        }

        private void datePicker_onValueChanged(object sender, EventArgs e)
        {
            MessageBox.Show(datePicker.Value.ToShortDateString());
        }
    }
}
