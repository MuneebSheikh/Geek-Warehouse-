﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using constructionSite.Controller;

namespace constructionSite.Views
{
    public partial class dashboard : Form
    {
        public dashboard()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnAddNewProject_Click(object sender, EventArgs e)
        {
            MainAddNewProject a = new MainAddNewProject();
            a.Show();
            this.Hide();
        }

        private void dashboard_Load(object sender, EventArgs e)
        {
            try
            {
                accessProject a= new accessProject();
                DataTable dt = a.GetProjects();

                ////////////// Binding Selected Columns of DGRID1//////////////////////

                dgvDashboard.AutoGenerateColumns = false;
                dgvDashboard.ColumnCount = 3;
                dgvDashboard.Columns[0].HeaderText = "Plot No";
                dgvDashboard.Columns[0].Name = "plotNo";
                dgvDashboard.Columns[0].DataPropertyName = "plotNo";
                dgvDashboard.Columns[1].HeaderText = "Client Name";
                dgvDashboard.Columns[1].DataPropertyName = "clientName";
                dgvDashboard.Columns[2].HeaderText = "Status";
                dgvDashboard.Columns[2].DataPropertyName = "status";

                dgvDashboard.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void dgvDashboard_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            String plotID = "";
               
            if(e.RowIndex >= 0)
            {
                DataGridViewRow row = this.dgvDashboard.Rows[e.RowIndex];
                plotID = row.Cells["plotNo"].Value.ToString();
                

                addNewProject a = new addNewProject();
                a.PlotIDVal = plotID;
                a.Show();
                this.Hide();
            }

            


        }
    }
}
