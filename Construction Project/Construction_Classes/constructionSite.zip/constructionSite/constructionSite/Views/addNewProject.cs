﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using constructionSite.Controller;
using System.Globalization;

namespace constructionSite.Views
{
    public partial class addNewProject : Form
    {
        public addNewProject()
        {
            InitializeComponent();
        }
        public string PlotIDVal { get; set; }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            dashboard d = new dashboard();
            d.Show();
            this.Hide();
        }

        private void btnAddnewWorker_Click(object sender, EventArgs e)
        {
            AddNewWorker a = new AddNewWorker();
            a.Show();
            this.Hide();
        }

        private void btnAddNewCompany_Click(object sender, EventArgs e)
        {
            addNewCompany a = new addNewCompany();
            a.Show();
            this.Hide();
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            PrintScreen p = new PrintScreen();
            p.Show();
            this.Hide();
        }

        private void btnDasti_Click(object sender, EventArgs e)
        {

            patyCash p = new patyCash();
            p.Show();
            this.Hide();
        }

        private void btnRecivePayment_Click(object sender, EventArgs e)
        {
            RecivePayment r = new RecivePayment();
            r.Show();
            this.Hide();
        }

        private void btnCompanyDetails_Click(object sender, EventArgs e)
        {
            CompanyRecordDtails c = new CompanyRecordDtails();
            c.Show();
            this.Hide();
        }

        private void btnWorkerDetails_Click(object sender, EventArgs e)
        {
            workerRecordDetails w = new workerRecordDetails();
            w.Show();
            this.Hide();
        }

        private void txtContactNumber_OnValueChanged(object sender, EventArgs e)
        {
            txtContactNumber.Text = string.Concat(txtContactNumber.Text.Where(char.IsDigit));
        }

        private void txtName_OnValueChanged(object sender, EventArgs e)
        {
            txtName.Text = string.Concat(txtName.Text.Where(char.IsLetter));
        }
        

        private void datePicker_onValueChanged(object sender, EventArgs e)
        {
            MessageBox.Show(datePicker.Value.ToShortDateString());
        }

        private void txtPlotID_OnValueChanged(object sender, EventArgs e)
        {
            txtPlotID.Text = string.Concat(txtPlotID.Text.Where(char.IsLetterOrDigit));
        }

        private void txtContactNumber_Leave(object sender, EventArgs e)
        {
            string text = txtContactNumber.Text;
            if(text.Length != 11)
            {
                MessageBox.Show("Invald Contact Number");
                txtContactNumber.Focus();
            }
        }

        private void addNewProject_Load(object sender, EventArgs e)
        {

            try
            {

                Project p = new Project();
                p.plotNo = PlotIDVal;

                string pattern = "dd/MM/yyyy HH:mm:ss";
                DateTime parsedDate;
                string dateValue = p.date;
                DateTime.TryParseExact(dateValue, pattern, null,
                                  DateTimeStyles.None, out parsedDate);
                                  
                txtName.Text = p.name;
                txtContactNumber.Text = p.contactNo;
                txtPlotID.Text = p.plotNo;
                txtStatus.Text = p.status;

                DataTable dt = p.getSelectedProjectPaymentData();

                //////////// Binding Selected Columns of Datagrid//////////////////////

                dgvPayment.AutoGenerateColumns = false;
                dgvPayment.ColumnCount = 5;
                dgvPayment.Columns[0].HeaderText = "Date";
                dgvPayment.Columns[0].DataPropertyName = "date";
                dgvPayment.Columns[1].HeaderText = "Particuler";
                dgvPayment.Columns[1].DataPropertyName = "particuler";
                dgvPayment.Columns[2].HeaderText = "Debt";
                dgvPayment.Columns[2].DataPropertyName = "debt";
                dgvPayment.Columns[2].HeaderText = "Credit";
                dgvPayment.Columns[2].DataPropertyName = "credit";
                dgvPayment.Columns[2].HeaderText = "Balance";
                dgvPayment.Columns[2].DataPropertyName = "balance";

                dgvPayment.DataSource = dt;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
    }
}
