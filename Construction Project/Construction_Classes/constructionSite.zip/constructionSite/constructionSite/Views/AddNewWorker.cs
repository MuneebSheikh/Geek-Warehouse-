﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;
using System.Net.Mail;

namespace constructionSite.Views
{
    public partial class AddNewWorker : Form
    {
        public AddNewWorker()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            dashboard d = new dashboard();
            d.Show();
            this.Hide();

        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            addNewProject a = new addNewProject();
            a.Show();
            this.Hide();
        }

        private void btnAddNewBill_Click(object sender, EventArgs e)
        {
            addNewBill a = new addNewBill();
            a.Show();
            this.Hide();
        }

        private void txtPersonName_OnValueChanged(object sender, EventArgs e)
        {
            txtPersonName.Text = string.Concat(txtPersonName.Text.Where(char.IsLetter));
        }

        private void txtContactNumber_OnValueChanged(object sender, EventArgs e)
        {
            txtContactNumber.Text = string.Concat(txtContactNumber.Text.Where(char.IsDigit));
        }
  

        private void txtTypeOfWork_OnValueChanged(object sender, EventArgs e)
        {
            txtTypeOfWork.Text = string.Concat(txtTypeOfWork.Text.Where(char.IsLetter));
        }

        private void txtCNIC_Leave(object sender, EventArgs e)
        {
            if (!Regex.Match(txtCNIC.Text, "^[0-9]{5}-[0-9]{7}-[0-9]{1}$").Success)
            {
                MessageBox.Show("Invalid CNIC");
                txtCNIC.Focus();
            }
            
        }

        private void txtEmail_Leave(object sender, EventArgs e)
        {
            try
            {
                MailAddress m = new MailAddress(txtEmail.Text);
            }
            catch (FormatException)
            {
                MessageBox.Show("Invalid Email Address");
                txtEmail.Focus();
            }
        }

        private void txtContactNumber_Leave(object sender, EventArgs e)
        {
            string text = txtContactNumber.Text;
            if (text.Length != 11)
            {
                MessageBox.Show("Invald Contact Number");
                txtContactNumber.Focus();
            }
        }
    }
}
