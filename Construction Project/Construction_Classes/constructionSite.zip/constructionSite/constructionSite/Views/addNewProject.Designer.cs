﻿namespace constructionSite.Views
{
    partial class addNewProject
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(addNewProject));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.btnExit = new Bunifu.Framework.UI.BunifuImageButton();
            this.btnMinimize = new Bunifu.Framework.UI.BunifuImageButton();
            this.btnDashboard = new Bunifu.Framework.UI.BunifuFlatButton();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblRemaingAmount = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.datePicker = new Bunifu.Framework.UI.BunifuDatepicker();
            this.btnRecivePayment = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnDelete = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnUpdate = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnWorkerDetails = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnCompanyDetails = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnDasti = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnSave = new Bunifu.Framework.UI.BunifuFlatButton();
            this.dgvPayment = new Bunifu.Framework.UI.BunifuCustomDataGrid();
            this.colDate = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colParticular = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colDebit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colCredit = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.colBalance = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.txtTotalPayment = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label8 = new System.Windows.Forms.Label();
            this.btnAddnewWorker = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnAddNewCompany = new Bunifu.Framework.UI.BunifuFlatButton();
            this.btnPrint = new Bunifu.Framework.UI.BunifuFlatButton();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPlotID = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtContactNumber = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtName = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            this.label1 = new System.Windows.Forms.Label();
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.btnBack = new Bunifu.Framework.UI.BunifuFlatButton();
            this.txtStatus = new Bunifu.Framework.UI.BunifuMaterialTextbox();
            ((System.ComponentModel.ISupportInitialize)(this.btnExit)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMinimize)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPayment)).BeginInit();
            this.panel2.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnExit
            // 
            this.btnExit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnExit.Image = ((System.Drawing.Image)(resources.GetObject("btnExit.Image")));
            this.btnExit.ImageActive = null;
            this.btnExit.Location = new System.Drawing.Point(902, 12);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(28, 18);
            this.btnExit.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnExit.TabIndex = 6;
            this.btnExit.TabStop = false;
            this.btnExit.Zoom = 10;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnMinimize
            // 
            this.btnMinimize.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnMinimize.Image = ((System.Drawing.Image)(resources.GetObject("btnMinimize.Image")));
            this.btnMinimize.ImageActive = null;
            this.btnMinimize.Location = new System.Drawing.Point(852, 12);
            this.btnMinimize.Name = "btnMinimize";
            this.btnMinimize.Size = new System.Drawing.Size(28, 18);
            this.btnMinimize.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.btnMinimize.TabIndex = 5;
            this.btnMinimize.TabStop = false;
            this.btnMinimize.Zoom = 10;
            this.btnMinimize.Click += new System.EventHandler(this.btnMinimize_Click);
            // 
            // btnDashboard
            // 
            this.btnDashboard.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnDashboard.BackColor = System.Drawing.Color.Transparent;
            this.btnDashboard.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDashboard.BorderRadius = 5;
            this.btnDashboard.ButtonText = "DashBoard";
            this.btnDashboard.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDashboard.DisabledColor = System.Drawing.Color.Gray;
            this.btnDashboard.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDashboard.ForeColor = System.Drawing.Color.Black;
            this.btnDashboard.Iconcolor = System.Drawing.Color.Transparent;
            this.btnDashboard.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnDashboard.Iconimage")));
            this.btnDashboard.Iconimage_right = null;
            this.btnDashboard.Iconimage_right_Selected = null;
            this.btnDashboard.Iconimage_Selected = null;
            this.btnDashboard.IconMarginLeft = 0;
            this.btnDashboard.IconMarginRight = 0;
            this.btnDashboard.IconRightVisible = true;
            this.btnDashboard.IconRightZoom = 0D;
            this.btnDashboard.IconVisible = true;
            this.btnDashboard.IconZoom = 70D;
            this.btnDashboard.IsTab = false;
            this.btnDashboard.Location = new System.Drawing.Point(110, 12);
            this.btnDashboard.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.btnDashboard.Name = "btnDashboard";
            this.btnDashboard.Normalcolor = System.Drawing.Color.Transparent;
            this.btnDashboard.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(142)))), ((int)(((byte)(233)))));
            this.btnDashboard.OnHoverTextColor = System.Drawing.Color.White;
            this.btnDashboard.selected = false;
            this.btnDashboard.Size = new System.Drawing.Size(192, 38);
            this.btnDashboard.TabIndex = 8;
            this.btnDashboard.Text = "DashBoard";
            this.btnDashboard.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDashboard.Textcolor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(142)))), ((int)(((byte)(233)))));
            this.btnDashboard.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDashboard.Click += new System.EventHandler(this.btnDashboard_Click);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.txtStatus);
            this.panel1.Controls.Add(this.lblRemaingAmount);
            this.panel1.Controls.Add(this.label6);
            this.panel1.Controls.Add(this.datePicker);
            this.panel1.Controls.Add(this.btnRecivePayment);
            this.panel1.Controls.Add(this.btnDelete);
            this.panel1.Controls.Add(this.btnUpdate);
            this.panel1.Controls.Add(this.btnWorkerDetails);
            this.panel1.Controls.Add(this.btnCompanyDetails);
            this.panel1.Controls.Add(this.btnDasti);
            this.panel1.Controls.Add(this.btnSave);
            this.panel1.Controls.Add(this.dgvPayment);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.btnAddnewWorker);
            this.panel1.Controls.Add(this.btnAddNewCompany);
            this.panel1.Controls.Add(this.btnPrint);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.label7);
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.txtPlotID);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.txtContactNumber);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.txtName);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(61, 79);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(842, 822);
            this.panel1.TabIndex = 9;
            // 
            // lblRemaingAmount
            // 
            this.lblRemaingAmount.AutoSize = true;
            this.lblRemaingAmount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRemaingAmount.Location = new System.Drawing.Point(728, 218);
            this.lblRemaingAmount.Name = "lblRemaingAmount";
            this.lblRemaingAmount.Size = new System.Drawing.Size(91, 20);
            this.lblRemaingAmount.TabIndex = 80;
            this.lblRemaingAmount.Text = "12000 PKrs";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(540, 218);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(182, 20);
            this.label6.TabIndex = 79;
            this.label6.Text = "Dasti Remaing Amount :";
            // 
            // datePicker
            // 
            this.datePicker.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.datePicker.BorderRadius = 0;
            this.datePicker.ForeColor = System.Drawing.Color.White;
            this.datePicker.Format = System.Windows.Forms.DateTimePickerFormat.Long;
            this.datePicker.FormatCustom = null;
            this.datePicker.Location = new System.Drawing.Point(50, 79);
            this.datePicker.Margin = new System.Windows.Forms.Padding(6, 6, 6, 6);
            this.datePicker.Name = "datePicker";
            this.datePicker.Size = new System.Drawing.Size(200, 39);
            this.datePicker.TabIndex = 78;
            this.datePicker.Value = new System.DateTime(2019, 10, 5, 13, 29, 49, 474);
            this.datePicker.onValueChanged += new System.EventHandler(this.datePicker_onValueChanged);
            // 
            // btnRecivePayment
            // 
            this.btnRecivePayment.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnRecivePayment.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnRecivePayment.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnRecivePayment.BorderRadius = 0;
            this.btnRecivePayment.ButtonText = "Recive Payment";
            this.btnRecivePayment.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnRecivePayment.DisabledColor = System.Drawing.Color.Gray;
            this.btnRecivePayment.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRecivePayment.Iconcolor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(142)))), ((int)(((byte)(233)))));
            this.btnRecivePayment.Iconimage = null;
            this.btnRecivePayment.Iconimage_right = null;
            this.btnRecivePayment.Iconimage_right_Selected = null;
            this.btnRecivePayment.Iconimage_Selected = null;
            this.btnRecivePayment.IconMarginLeft = 0;
            this.btnRecivePayment.IconMarginRight = 0;
            this.btnRecivePayment.IconRightVisible = true;
            this.btnRecivePayment.IconRightZoom = 0D;
            this.btnRecivePayment.IconVisible = true;
            this.btnRecivePayment.IconZoom = 75D;
            this.btnRecivePayment.IsTab = false;
            this.btnRecivePayment.Location = new System.Drawing.Point(79, 305);
            this.btnRecivePayment.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.btnRecivePayment.Name = "btnRecivePayment";
            this.btnRecivePayment.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnRecivePayment.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnRecivePayment.OnHoverTextColor = System.Drawing.Color.White;
            this.btnRecivePayment.selected = false;
            this.btnRecivePayment.Size = new System.Drawing.Size(137, 42);
            this.btnRecivePayment.TabIndex = 77;
            this.btnRecivePayment.Text = "Recive Payment";
            this.btnRecivePayment.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnRecivePayment.Textcolor = System.Drawing.Color.White;
            this.btnRecivePayment.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRecivePayment.Click += new System.EventHandler(this.btnRecivePayment_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnDelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDelete.BorderRadius = 0;
            this.btnDelete.ButtonText = "  Delete";
            this.btnDelete.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDelete.DisabledColor = System.Drawing.Color.Gray;
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Iconcolor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(142)))), ((int)(((byte)(233)))));
            this.btnDelete.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnDelete.Iconimage")));
            this.btnDelete.Iconimage_right = null;
            this.btnDelete.Iconimage_right_Selected = null;
            this.btnDelete.Iconimage_Selected = null;
            this.btnDelete.IconMarginLeft = 0;
            this.btnDelete.IconMarginRight = 0;
            this.btnDelete.IconRightVisible = true;
            this.btnDelete.IconRightZoom = 0D;
            this.btnDelete.IconVisible = true;
            this.btnDelete.IconZoom = 75D;
            this.btnDelete.IsTab = false;
            this.btnDelete.Location = new System.Drawing.Point(440, 718);
            this.btnDelete.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnDelete.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnDelete.OnHoverTextColor = System.Drawing.Color.White;
            this.btnDelete.selected = false;
            this.btnDelete.Size = new System.Drawing.Size(192, 42);
            this.btnDelete.TabIndex = 76;
            this.btnDelete.Text = "  Delete";
            this.btnDelete.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnDelete.Textcolor = System.Drawing.Color.White;
            this.btnDelete.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnUpdate
            // 
            this.btnUpdate.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnUpdate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnUpdate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnUpdate.BorderRadius = 0;
            this.btnUpdate.ButtonText = "  Update";
            this.btnUpdate.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnUpdate.DisabledColor = System.Drawing.Color.Gray;
            this.btnUpdate.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.Iconcolor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(142)))), ((int)(((byte)(233)))));
            this.btnUpdate.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnUpdate.Iconimage")));
            this.btnUpdate.Iconimage_right = null;
            this.btnUpdate.Iconimage_right_Selected = null;
            this.btnUpdate.Iconimage_Selected = null;
            this.btnUpdate.IconMarginLeft = 0;
            this.btnUpdate.IconMarginRight = 0;
            this.btnUpdate.IconRightVisible = true;
            this.btnUpdate.IconRightZoom = 0D;
            this.btnUpdate.IconVisible = true;
            this.btnUpdate.IconZoom = 75D;
            this.btnUpdate.IsTab = false;
            this.btnUpdate.Location = new System.Drawing.Point(217, 718);
            this.btnUpdate.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnUpdate.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnUpdate.OnHoverTextColor = System.Drawing.Color.White;
            this.btnUpdate.selected = false;
            this.btnUpdate.Size = new System.Drawing.Size(192, 42);
            this.btnUpdate.TabIndex = 75;
            this.btnUpdate.Text = "  Update";
            this.btnUpdate.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnUpdate.Textcolor = System.Drawing.Color.White;
            this.btnUpdate.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // btnWorkerDetails
            // 
            this.btnWorkerDetails.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnWorkerDetails.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnWorkerDetails.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnWorkerDetails.BorderRadius = 0;
            this.btnWorkerDetails.ButtonText = "Worker Details";
            this.btnWorkerDetails.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnWorkerDetails.DisabledColor = System.Drawing.Color.Gray;
            this.btnWorkerDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWorkerDetails.Iconcolor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(142)))), ((int)(((byte)(233)))));
            this.btnWorkerDetails.Iconimage = null;
            this.btnWorkerDetails.Iconimage_right = null;
            this.btnWorkerDetails.Iconimage_right_Selected = null;
            this.btnWorkerDetails.Iconimage_Selected = null;
            this.btnWorkerDetails.IconMarginLeft = 0;
            this.btnWorkerDetails.IconMarginRight = 0;
            this.btnWorkerDetails.IconRightVisible = true;
            this.btnWorkerDetails.IconRightZoom = 0D;
            this.btnWorkerDetails.IconVisible = true;
            this.btnWorkerDetails.IconZoom = 75D;
            this.btnWorkerDetails.IsTab = false;
            this.btnWorkerDetails.Location = new System.Drawing.Point(522, 305);
            this.btnWorkerDetails.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.btnWorkerDetails.Name = "btnWorkerDetails";
            this.btnWorkerDetails.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnWorkerDetails.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnWorkerDetails.OnHoverTextColor = System.Drawing.Color.White;
            this.btnWorkerDetails.selected = false;
            this.btnWorkerDetails.Size = new System.Drawing.Size(137, 42);
            this.btnWorkerDetails.TabIndex = 34;
            this.btnWorkerDetails.Text = "Worker Details";
            this.btnWorkerDetails.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnWorkerDetails.Textcolor = System.Drawing.Color.White;
            this.btnWorkerDetails.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnWorkerDetails.Click += new System.EventHandler(this.btnWorkerDetails_Click);
            // 
            // btnCompanyDetails
            // 
            this.btnCompanyDetails.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnCompanyDetails.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnCompanyDetails.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCompanyDetails.BorderRadius = 0;
            this.btnCompanyDetails.ButtonText = "Company Details";
            this.btnCompanyDetails.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnCompanyDetails.DisabledColor = System.Drawing.Color.Gray;
            this.btnCompanyDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCompanyDetails.Iconcolor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(142)))), ((int)(((byte)(233)))));
            this.btnCompanyDetails.Iconimage = null;
            this.btnCompanyDetails.Iconimage_right = null;
            this.btnCompanyDetails.Iconimage_right_Selected = null;
            this.btnCompanyDetails.Iconimage_Selected = null;
            this.btnCompanyDetails.IconMarginLeft = 0;
            this.btnCompanyDetails.IconMarginRight = 0;
            this.btnCompanyDetails.IconRightVisible = true;
            this.btnCompanyDetails.IconRightZoom = 0D;
            this.btnCompanyDetails.IconVisible = true;
            this.btnCompanyDetails.IconZoom = 75D;
            this.btnCompanyDetails.IsTab = false;
            this.btnCompanyDetails.Location = new System.Drawing.Point(302, 305);
            this.btnCompanyDetails.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.btnCompanyDetails.Name = "btnCompanyDetails";
            this.btnCompanyDetails.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnCompanyDetails.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnCompanyDetails.OnHoverTextColor = System.Drawing.Color.White;
            this.btnCompanyDetails.selected = false;
            this.btnCompanyDetails.Size = new System.Drawing.Size(137, 42);
            this.btnCompanyDetails.TabIndex = 33;
            this.btnCompanyDetails.Text = "Company Details";
            this.btnCompanyDetails.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnCompanyDetails.Textcolor = System.Drawing.Color.White;
            this.btnCompanyDetails.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCompanyDetails.Click += new System.EventHandler(this.btnCompanyDetails_Click);
            // 
            // btnDasti
            // 
            this.btnDasti.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnDasti.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnDasti.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDasti.BorderRadius = 0;
            this.btnDasti.ButtonText = "Dasti";
            this.btnDasti.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnDasti.DisabledColor = System.Drawing.Color.Gray;
            this.btnDasti.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDasti.Iconcolor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(142)))), ((int)(((byte)(233)))));
            this.btnDasti.Iconimage = null;
            this.btnDasti.Iconimage_right = null;
            this.btnDasti.Iconimage_right_Selected = null;
            this.btnDasti.Iconimage_Selected = null;
            this.btnDasti.IconMarginLeft = 0;
            this.btnDasti.IconMarginRight = 0;
            this.btnDasti.IconRightVisible = true;
            this.btnDasti.IconRightZoom = 0D;
            this.btnDasti.IconVisible = true;
            this.btnDasti.IconZoom = 75D;
            this.btnDasti.IsTab = false;
            this.btnDasti.Location = new System.Drawing.Point(719, 305);
            this.btnDasti.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.btnDasti.Name = "btnDasti";
            this.btnDasti.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnDasti.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnDasti.OnHoverTextColor = System.Drawing.Color.White;
            this.btnDasti.selected = false;
            this.btnDasti.Size = new System.Drawing.Size(91, 42);
            this.btnDasti.TabIndex = 31;
            this.btnDasti.Text = "Dasti";
            this.btnDasti.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnDasti.Textcolor = System.Drawing.Color.White;
            this.btnDasti.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDasti.Click += new System.EventHandler(this.btnDasti_Click);
            // 
            // btnSave
            // 
            this.btnSave.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnSave.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSave.BorderRadius = 0;
            this.btnSave.ButtonText = "  Save";
            this.btnSave.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnSave.DisabledColor = System.Drawing.Color.Gray;
            this.btnSave.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSave.Iconcolor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(142)))), ((int)(((byte)(233)))));
            this.btnSave.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnSave.Iconimage")));
            this.btnSave.Iconimage_right = null;
            this.btnSave.Iconimage_right_Selected = null;
            this.btnSave.Iconimage_Selected = null;
            this.btnSave.IconMarginLeft = 0;
            this.btnSave.IconMarginRight = 0;
            this.btnSave.IconRightVisible = true;
            this.btnSave.IconRightZoom = 0D;
            this.btnSave.IconVisible = true;
            this.btnSave.IconZoom = 75D;
            this.btnSave.IsTab = false;
            this.btnSave.Location = new System.Drawing.Point(644, 718);
            this.btnSave.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.btnSave.Name = "btnSave";
            this.btnSave.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnSave.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnSave.OnHoverTextColor = System.Drawing.Color.White;
            this.btnSave.selected = false;
            this.btnSave.Size = new System.Drawing.Size(192, 42);
            this.btnSave.TabIndex = 30;
            this.btnSave.Text = "  Save";
            this.btnSave.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnSave.Textcolor = System.Drawing.Color.White;
            this.btnSave.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // dgvPayment
            // 
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.dgvPayment.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvPayment.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvPayment.BackgroundColor = System.Drawing.Color.White;
            this.dgvPayment.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.dgvPayment.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.White;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvPayment.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dgvPayment.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.colDate,
            this.colParticular,
            this.colDebit,
            this.colCredit,
            this.colBalance});
            this.dgvPayment.DoubleBuffered = true;
            this.dgvPayment.Enabled = false;
            this.dgvPayment.EnableHeadersVisualStyles = false;
            this.dgvPayment.GridColor = System.Drawing.SystemColors.ControlDarkDark;
            this.dgvPayment.HeaderBgColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.dgvPayment.HeaderForeColor = System.Drawing.Color.White;
            this.dgvPayment.Location = new System.Drawing.Point(10, 408);
            this.dgvPayment.Name = "dgvPayment";
            this.dgvPayment.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            this.dgvPayment.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.AutoSizeToDisplayedHeaders;
            this.dgvPayment.RowTemplate.Height = 20;
            this.dgvPayment.Size = new System.Drawing.Size(829, 290);
            this.dgvPayment.TabIndex = 29;
            // 
            // colDate
            // 
            this.colDate.FillWeight = 68.51747F;
            this.colDate.HeaderText = "Date";
            this.colDate.Name = "colDate";
            // 
            // colParticular
            // 
            this.colParticular.FillWeight = 261.3844F;
            this.colParticular.HeaderText = "Particular";
            this.colParticular.Name = "colParticular";
            // 
            // colDebit
            // 
            this.colDebit.HeaderText = "Debit";
            this.colDebit.Name = "colDebit";
            // 
            // colCredit
            // 
            this.colCredit.HeaderText = "Credit";
            this.colCredit.Name = "colCredit";
            // 
            // colBalance
            // 
            this.colBalance.HeaderText = "Balance";
            this.colBalance.Name = "colBalance";
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.txtTotalPayment);
            this.panel2.Controls.Add(this.label8);
            this.panel2.Location = new System.Drawing.Point(7, 354);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(832, 48);
            this.panel2.TabIndex = 28;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(465, 15);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(110, 20);
            this.label9.TabIndex = 24;
            this.label9.Text = "Total Payment";
            // 
            // txtTotalPayment
            // 
            this.txtTotalPayment.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtTotalPayment.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtTotalPayment.Enabled = false;
            this.txtTotalPayment.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtTotalPayment.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.txtTotalPayment.HintForeColor = System.Drawing.Color.Empty;
            this.txtTotalPayment.HintText = "";
            this.txtTotalPayment.isPassword = false;
            this.txtTotalPayment.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtTotalPayment.LineIdleColor = System.Drawing.Color.Gray;
            this.txtTotalPayment.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtTotalPayment.LineThickness = 3;
            this.txtTotalPayment.Location = new System.Drawing.Point(582, 4);
            this.txtTotalPayment.Margin = new System.Windows.Forms.Padding(4);
            this.txtTotalPayment.Name = "txtTotalPayment";
            this.txtTotalPayment.Size = new System.Drawing.Size(200, 32);
            this.txtTotalPayment.TabIndex = 21;
            this.txtTotalPayment.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(48, 15);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(71, 20);
            this.label8.TabIndex = 14;
            this.label8.Text = "Payment";
            // 
            // btnAddnewWorker
            // 
            this.btnAddnewWorker.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnAddnewWorker.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnAddnewWorker.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAddnewWorker.BorderRadius = 0;
            this.btnAddnewWorker.ButtonText = "";
            this.btnAddnewWorker.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddnewWorker.DisabledColor = System.Drawing.Color.Gray;
            this.btnAddnewWorker.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddnewWorker.Iconcolor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(142)))), ((int)(((byte)(233)))));
            this.btnAddnewWorker.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnAddnewWorker.Iconimage")));
            this.btnAddnewWorker.Iconimage_right = null;
            this.btnAddnewWorker.Iconimage_right_Selected = null;
            this.btnAddnewWorker.Iconimage_Selected = null;
            this.btnAddnewWorker.IconMarginLeft = 0;
            this.btnAddnewWorker.IconMarginRight = 0;
            this.btnAddnewWorker.IconRightVisible = true;
            this.btnAddnewWorker.IconRightZoom = 0D;
            this.btnAddnewWorker.IconVisible = true;
            this.btnAddnewWorker.IconZoom = 75D;
            this.btnAddnewWorker.IsTab = false;
            this.btnAddnewWorker.Location = new System.Drawing.Point(476, 305);
            this.btnAddnewWorker.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.btnAddnewWorker.Name = "btnAddnewWorker";
            this.btnAddnewWorker.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnAddnewWorker.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnAddnewWorker.OnHoverTextColor = System.Drawing.Color.White;
            this.btnAddnewWorker.selected = false;
            this.btnAddnewWorker.Size = new System.Drawing.Size(43, 42);
            this.btnAddnewWorker.TabIndex = 27;
            this.btnAddnewWorker.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddnewWorker.Textcolor = System.Drawing.Color.White;
            this.btnAddnewWorker.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddnewWorker.Click += new System.EventHandler(this.btnAddnewWorker_Click);
            // 
            // btnAddNewCompany
            // 
            this.btnAddNewCompany.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnAddNewCompany.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnAddNewCompany.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAddNewCompany.BorderRadius = 0;
            this.btnAddNewCompany.ButtonText = "";
            this.btnAddNewCompany.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnAddNewCompany.DisabledColor = System.Drawing.Color.Gray;
            this.btnAddNewCompany.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddNewCompany.Iconcolor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(142)))), ((int)(((byte)(233)))));
            this.btnAddNewCompany.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnAddNewCompany.Iconimage")));
            this.btnAddNewCompany.Iconimage_right = null;
            this.btnAddNewCompany.Iconimage_right_Selected = null;
            this.btnAddNewCompany.Iconimage_Selected = null;
            this.btnAddNewCompany.IconMarginLeft = 0;
            this.btnAddNewCompany.IconMarginRight = 0;
            this.btnAddNewCompany.IconRightVisible = true;
            this.btnAddNewCompany.IconRightZoom = 0D;
            this.btnAddNewCompany.IconVisible = true;
            this.btnAddNewCompany.IconZoom = 75D;
            this.btnAddNewCompany.IsTab = false;
            this.btnAddNewCompany.Location = new System.Drawing.Point(257, 305);
            this.btnAddNewCompany.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.btnAddNewCompany.Name = "btnAddNewCompany";
            this.btnAddNewCompany.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnAddNewCompany.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnAddNewCompany.OnHoverTextColor = System.Drawing.Color.White;
            this.btnAddNewCompany.selected = false;
            this.btnAddNewCompany.Size = new System.Drawing.Size(42, 42);
            this.btnAddNewCompany.TabIndex = 26;
            this.btnAddNewCompany.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnAddNewCompany.Textcolor = System.Drawing.Color.White;
            this.btnAddNewCompany.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAddNewCompany.Click += new System.EventHandler(this.btnAddNewCompany_Click);
            // 
            // btnPrint
            // 
            this.btnPrint.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnPrint.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnPrint.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPrint.BorderRadius = 0;
            this.btnPrint.ButtonText = "";
            this.btnPrint.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnPrint.DisabledColor = System.Drawing.Color.Gray;
            this.btnPrint.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrint.Iconcolor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(142)))), ((int)(((byte)(233)))));
            this.btnPrint.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnPrint.Iconimage")));
            this.btnPrint.Iconimage_right = null;
            this.btnPrint.Iconimage_right_Selected = null;
            this.btnPrint.Iconimage_Selected = null;
            this.btnPrint.IconMarginLeft = 0;
            this.btnPrint.IconMarginRight = 0;
            this.btnPrint.IconRightVisible = true;
            this.btnPrint.IconRightZoom = 0D;
            this.btnPrint.IconVisible = true;
            this.btnPrint.IconZoom = 75D;
            this.btnPrint.IsTab = false;
            this.btnPrint.Location = new System.Drawing.Point(39, 305);
            this.btnPrint.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.btnPrint.Name = "btnPrint";
            this.btnPrint.Normalcolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnPrint.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnPrint.OnHoverTextColor = System.Drawing.Color.White;
            this.btnPrint.selected = false;
            this.btnPrint.Size = new System.Drawing.Size(37, 42);
            this.btnPrint.TabIndex = 25;
            this.btnPrint.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnPrint.Textcolor = System.Drawing.Color.White;
            this.btnPrint.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPrint.Click += new System.EventHandler(this.btnPrint_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(540, 120);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 20);
            this.label5.TabIndex = 23;
            this.label5.Text = "Status";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(45, 56);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 20);
            this.label7.TabIndex = 19;
            this.label7.Text = "Date";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(541, 56);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(96, 20);
            this.label4.TabIndex = 17;
            this.label4.Text = "Plot Number";
            // 
            // txtPlotID
            // 
            this.txtPlotID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtPlotID.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtPlotID.Enabled = false;
            this.txtPlotID.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtPlotID.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.txtPlotID.HintForeColor = System.Drawing.Color.Empty;
            this.txtPlotID.HintText = "";
            this.txtPlotID.isPassword = false;
            this.txtPlotID.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtPlotID.LineIdleColor = System.Drawing.Color.Gray;
            this.txtPlotID.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtPlotID.LineThickness = 3;
            this.txtPlotID.Location = new System.Drawing.Point(545, 80);
            this.txtPlotID.Margin = new System.Windows.Forms.Padding(4);
            this.txtPlotID.Name = "txtPlotID";
            this.txtPlotID.Size = new System.Drawing.Size(200, 32);
            this.txtPlotID.TabIndex = 16;
            this.txtPlotID.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtPlotID.OnValueChanged += new System.EventHandler(this.txtPlotID_OnValueChanged);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(45, 194);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(125, 20);
            this.label3.TabIndex = 15;
            this.label3.Text = "Conatct Number";
            // 
            // txtContactNumber
            // 
            this.txtContactNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtContactNumber.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtContactNumber.Enabled = false;
            this.txtContactNumber.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtContactNumber.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.txtContactNumber.HintForeColor = System.Drawing.Color.Empty;
            this.txtContactNumber.HintText = "";
            this.txtContactNumber.isPassword = false;
            this.txtContactNumber.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtContactNumber.LineIdleColor = System.Drawing.Color.Gray;
            this.txtContactNumber.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtContactNumber.LineThickness = 3;
            this.txtContactNumber.Location = new System.Drawing.Point(49, 218);
            this.txtContactNumber.Margin = new System.Windows.Forms.Padding(4);
            this.txtContactNumber.Name = "txtContactNumber";
            this.txtContactNumber.Size = new System.Drawing.Size(200, 32);
            this.txtContactNumber.TabIndex = 14;
            this.txtContactNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtContactNumber.OnValueChanged += new System.EventHandler(this.txtContactNumber_OnValueChanged);
            this.txtContactNumber.Leave += new System.EventHandler(this.txtContactNumber_Leave);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(45, 125);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(51, 20);
            this.label2.TabIndex = 13;
            this.label2.Text = "Name";
            // 
            // txtName
            // 
            this.txtName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtName.Enabled = false;
            this.txtName.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtName.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.txtName.HintForeColor = System.Drawing.Color.Empty;
            this.txtName.HintText = "";
            this.txtName.isPassword = false;
            this.txtName.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtName.LineIdleColor = System.Drawing.Color.Gray;
            this.txtName.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtName.LineThickness = 3;
            this.txtName.Location = new System.Drawing.Point(49, 149);
            this.txtName.Margin = new System.Windows.Forms.Padding(4);
            this.txtName.Name = "txtName";
            this.txtName.Size = new System.Drawing.Size(200, 32);
            this.txtName.TabIndex = 12;
            this.txtName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtName.OnValueChanged += new System.EventHandler(this.txtName_OnValueChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(26, 17);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(239, 24);
            this.label1.TabIndex = 6;
            this.label1.Text = "(Person Name From DB)";
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this;
            this.bunifuDragControl1.Vertical = true;
            // 
            // btnBack
            // 
            this.btnBack.Activecolor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.btnBack.BackColor = System.Drawing.Color.Transparent;
            this.btnBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBack.BorderRadius = 5;
            this.btnBack.ButtonText = "Back";
            this.btnBack.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnBack.DisabledColor = System.Drawing.Color.Gray;
            this.btnBack.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBack.ForeColor = System.Drawing.Color.Black;
            this.btnBack.Iconcolor = System.Drawing.Color.Transparent;
            this.btnBack.Iconimage = ((System.Drawing.Image)(resources.GetObject("btnBack.Iconimage")));
            this.btnBack.Iconimage_right = null;
            this.btnBack.Iconimage_right_Selected = null;
            this.btnBack.Iconimage_Selected = null;
            this.btnBack.IconMarginLeft = 0;
            this.btnBack.IconMarginRight = 0;
            this.btnBack.IconRightVisible = true;
            this.btnBack.IconRightZoom = 0D;
            this.btnBack.IconVisible = true;
            this.btnBack.IconZoom = 50D;
            this.btnBack.IsTab = false;
            this.btnBack.Location = new System.Drawing.Point(13, 12);
            this.btnBack.Margin = new System.Windows.Forms.Padding(6, 4, 6, 4);
            this.btnBack.Name = "btnBack";
            this.btnBack.Normalcolor = System.Drawing.Color.Transparent;
            this.btnBack.OnHovercolor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(142)))), ((int)(((byte)(233)))));
            this.btnBack.OnHoverTextColor = System.Drawing.Color.White;
            this.btnBack.selected = false;
            this.btnBack.Size = new System.Drawing.Size(85, 38);
            this.btnBack.TabIndex = 21;
            this.btnBack.Text = "Back";
            this.btnBack.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBack.Textcolor = System.Drawing.Color.FromArgb(((int)(((byte)(142)))), ((int)(((byte)(142)))), ((int)(((byte)(233)))));
            this.btnBack.TextFont = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            // 
            // txtStatus
            // 
            this.txtStatus.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtStatus.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtStatus.Enabled = false;
            this.txtStatus.Font = new System.Drawing.Font("Century Gothic", 9.75F);
            this.txtStatus.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(110)))), ((int)(((byte)(110)))), ((int)(((byte)(215)))));
            this.txtStatus.HintForeColor = System.Drawing.Color.Empty;
            this.txtStatus.HintText = "";
            this.txtStatus.isPassword = false;
            this.txtStatus.LineFocusedColor = System.Drawing.Color.Blue;
            this.txtStatus.LineIdleColor = System.Drawing.Color.Gray;
            this.txtStatus.LineMouseHoverColor = System.Drawing.Color.Blue;
            this.txtStatus.LineThickness = 3;
            this.txtStatus.Location = new System.Drawing.Point(545, 149);
            this.txtStatus.Margin = new System.Windows.Forms.Padding(4);
            this.txtStatus.Name = "txtStatus";
            this.txtStatus.Size = new System.Drawing.Size(200, 32);
            this.txtStatus.TabIndex = 81;
            this.txtStatus.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            // 
            // addNewProject
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(959, 780);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.btnDashboard);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnMinimize);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "addNewProject";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "addNewProject";
            this.Load += new System.EventHandler(this.addNewProject_Load);
            ((System.ComponentModel.ISupportInitialize)(this.btnExit)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.btnMinimize)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvPayment)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuImageButton btnExit;
        private Bunifu.Framework.UI.BunifuImageButton btnMinimize;
        private Bunifu.Framework.UI.BunifuFlatButton btnDashboard;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtName;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label4;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtPlotID;
        private System.Windows.Forms.Label label3;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtContactNumber;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label9;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtTotalPayment;
        private System.Windows.Forms.Label label8;
        private Bunifu.Framework.UI.BunifuFlatButton btnAddnewWorker;
        private Bunifu.Framework.UI.BunifuFlatButton btnAddNewCompany;
        private Bunifu.Framework.UI.BunifuFlatButton btnPrint;
        private Bunifu.Framework.UI.BunifuFlatButton btnSave;
        private Bunifu.Framework.UI.BunifuFlatButton btnWorkerDetails;
        private Bunifu.Framework.UI.BunifuFlatButton btnCompanyDetails;
        private Bunifu.Framework.UI.BunifuFlatButton btnDasti;
        private Bunifu.Framework.UI.BunifuFlatButton btnDelete;
        private Bunifu.Framework.UI.BunifuFlatButton btnUpdate;
        private Bunifu.Framework.UI.BunifuFlatButton btnRecivePayment;
        private Bunifu.Framework.UI.BunifuDatepicker datePicker;
        private Bunifu.Framework.UI.BunifuCustomDataGrid dgvPayment;
        private System.Windows.Forms.Label lblRemaingAmount;
        private System.Windows.Forms.Label label6;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDate;
        private System.Windows.Forms.DataGridViewTextBoxColumn colParticular;
        private System.Windows.Forms.DataGridViewTextBoxColumn colDebit;
        private System.Windows.Forms.DataGridViewTextBoxColumn colCredit;
        private System.Windows.Forms.DataGridViewTextBoxColumn colBalance;
        private Bunifu.Framework.UI.BunifuFlatButton btnBack;
        private Bunifu.Framework.UI.BunifuMaterialTextbox txtStatus;
    }
}