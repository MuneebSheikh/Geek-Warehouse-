﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using constructionSite.Controller;

namespace constructionSite.Views
{
    public partial class MainAddNewProject : Form
    {
        public MainAddNewProject()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            string theDate = datePicker.Value.ToString("dd-MM-yyyy");
            String Name = txtName.Text;
            String contactNumber = txtContactNumber.Text;
            string plotNumber = txtPlotID.Text;
            int statusIndex = cmbStatus.selectedIndex;

            if (statusIndex.ToString() != "-1")
            {
                string status = cmbStatus.Items[statusIndex].ToString();
                try
                {
                    if (theDate == "" || Name == "" || contactNumber == "" || plotNumber == "" || status == "")
                    {
                        MessageBox.Show("please fill all fields");
                    }
                    else
                    {
                        MessageBox.Show(theDate);
                        MessageBox.Show(Name);
                        MessageBox.Show(contactNumber);
                        MessageBox.Show(plotNumber);
                        MessageBox.Show(status);

                        accessProject a = new accessProject();
                        a.AddNewProject(theDate,Name,contactNumber,plotNumber,status);

                        dashboard d = new dashboard();
                        d.Show();
                        this.Hide();
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                MessageBox.Show("Please select Status");
            }

        }

        private void txtName_OnValueChanged(object sender, EventArgs e)
        {
            txtName.Text = string.Concat(txtName.Text.Where(char.IsLetter));
        }

        private void txtContactNumber_OnValueChanged(object sender, EventArgs e)
        {
            txtContactNumber.Text = string.Concat(txtContactNumber.Text.Where(char.IsDigit));
        }

        private void txtPlotID_OnValueChanged(object sender, EventArgs e)
        {
            txtPlotID.Text = string.Concat(txtPlotID.Text.Where(char.IsDigit));
        }

        private void txtContactNumber_Leave(object sender, EventArgs e)
        {
            string no = txtContactNumber.Text;
            if( no.Length != 11)
            {
                MessageBox.Show("Incorrect Contact Number");
                txtContactNumber.Focus();
            }
        }

        private void MainAddNewProject_Load(object sender, EventArgs e)
        {
            datePicker.Value = DateTime.Now;
        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            dashboard d = new dashboard();
            d.Show();
            this.Hide();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }
    }
}
