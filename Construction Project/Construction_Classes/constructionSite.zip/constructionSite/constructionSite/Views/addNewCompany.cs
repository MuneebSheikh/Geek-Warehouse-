﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace constructionSite.Views
{
    public partial class addNewCompany : Form
    {
        public addNewCompany()
        {
            InitializeComponent();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnMinimize_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnDashboard_Click(object sender, EventArgs e)
        {
            dashboard d = new dashboard();
            d.Show();
            this.Hide();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            addNewProject a = new addNewProject();
            a.Show();
            this.Hide();
        }

        private void btnAddNewBill_Click(object sender, EventArgs e)
        {
            addNewBill a = new addNewBill();
            a.Show();
            this.Hide();
        }

        private void txtCompanyName_OnValueChanged(object sender, EventArgs e)
        {
            txtCompanyName.Text = string.Concat(txtCompanyName.Text.Where(char.IsLetter));
        }

        private void txtShopAddress_OnValueChanged(object sender, EventArgs e)
        {
            txtShopAddress.Text = string.Concat(txtShopAddress.Text.Where(char.IsLetterOrDigit));
        }

        private void txtContactNumber_OnValueChanged(object sender, EventArgs e)
        {
            txtContactNumber.Text = string.Concat(txtContactNumber.Text.Where(char.IsDigit));
        }

        private void txtPersonName_OnValueChanged(object sender, EventArgs e)
        {
            txtPersonName.Text = string.Concat(txtPersonName.Text.Where(char.IsLetter));
        }

        private void txtType_OnValueChanged(object sender, EventArgs e)
        {
            txtType.Text = string.Concat(txtType.Text.Where(char.IsLetter));
        }

        private void txtContactNumber_Leave(object sender, EventArgs e)
        {
            string text = txtContactNumber.Text;
            if (text.Length != 11)
            {
                MessageBox.Show("Invald Contact Number");
                txtContactNumber.Focus();
            }
        }
    }
}
